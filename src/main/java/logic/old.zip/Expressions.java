package logic;

public class Expressions{
    public static final char NOT = 45;  // отрицание -
    public static final char IMP1 = 8594; // имплекация ->
    public static final char IMP2 = 62; // имплекация >
    public static final char AND = 38; // Коньюнкция &
    public static final char OR = 118; // Дизьюнкция v
    public static final char EQ = 124;  // штопор, эквивалентность |-
    public static final char HOP = 40; // (
    public static final char HCL = 41; // )
    public static final char ENUM = 44; //,

    char root;
    Expressions left, right;

    public static boolean isLogical(char c) {
        switch (c) {
            case NOT:
            case IMP1:
            case IMP2:
            case AND:
            case OR:
            case EQ:
            case ENUM:
                return true;
            default:
                return false;
        }
    }

    public static boolean isVariable(char c) {
        if ( (c >= 97 && c < 118) || (c > 118 && c <= 122) )
            return true;
        else if ( (c >= 65 && c < 86) || (c > 86 && c <= 90) )
            return true;
        return false;
    }

    public static int getPriority(char operation) {
        switch (operation) {
            case NOT:
                return 6;
            case AND:
                return 5;
            case OR:
                return 4;
            case IMP1:
            case IMP2:
                return 3;
            case ENUM:
                return 2;
            case EQ:
                return 1;
            default:
                return 0;
        }
    }

    public Expressions stringToExp(String expr) {
        int expLen = expr.length();
        int minPriority = Integer.MAX_VALUE;
        int minPriorityIndex = -1, hooks = 0;
        String left, right;

        char c = 0;
        for (int i = 0; i < expLen; i++)
        {
            c = expr.charAt(i);

            if (c == HOP) {
                hooks += 10;
                continue;
            } else if (c == HCL) {
                hooks -= 10;
                continue;
            }

            int prior = Expressions.getPriority(c);

            //Если выбрано отрицание && и оно самое низкоприоритетное, то продолжаем
            if (c == NOT && prior + hooks == minPriority) continue;

            //Если приоритет не пустой, и действие менее приоритетное, чем остальные
            if (prior > 0 && prior + hooks <= minPriority) {
                //Запоминаем самый низкий приоритет
                minPriority = prior + hooks;
                // и позицию символа с самым низким приоритетом
                minPriorityIndex = i;
            }
        }

        Expressions bt = new Expressions();

        if (minPriorityIndex == -1) { // нет операторов
            for (int i = 0; i < expLen; i++) {
                //System.out.println("write c1 = " + c);
                c = expr.charAt(i);
                if (Variable.isVariable(c)) {
                    // System.out.println("write c1 = " + c);
                    bt.root = c;
                    bt.left = null;
                    bt.right = null;
                    return bt;
                }
            }
        }

        //System.out.println("index = " +minPriorityIndex);
        c = expr.charAt(minPriorityIndex);

        //Проверка на наличие выражения слева и справа
        if (minPriorityIndex == 0){
            right = expr.substring(1, expLen);
            bt.root = c;
            bt.right = stringToExp(right);
            bt.left = null;
        } else if (minPriorityIndex == expLen - 1 ) {

            // System.out.println("write c = " + c);
            left = expr.substring(0, minPriorityIndex);
            bt.root = c;
            bt.left = stringToExp(left);
            bt.right = null;
        } else {
            left = expr.substring(0, minPriorityIndex);
            right = expr.substring(minPriorityIndex + 1, expLen);

            //System.out.println("write c = " + c);
            bt.root = c;
            bt.left = stringToExp(left);
            bt.right = stringToExp(right);
        }

        return bt;
    }

    char expToCharL() {
        char c;
        c = this.root;

        //  System.out.println("start = " + c);
        char left = 0, right = 0;

        //спуск до самого левого эллемента
        if (this.left != null){
            left = this.left.expToCharL();

        } else {
            System.out.println(c);
            return c;
        }

        if (this.right != null){
            right = this.right.expToCharL();
            return c;
        } else {
            System.out.println(c);
            return c;
        }

    }

    public String expToString() {
        char c;
        c = this.root;
        //  System.out.println(" c = " + c );

        String left = "", right = "";

        if (this.left != null){
            left = this.left.expToString();
        }

        if (this.right != null){
            right = this.right.expToString();
        }

       // System.out.println("v: " + left + c + right );
        return left + c + right ;
    }

    public int depth(Expressions expr) {
        int d1 = 0, d2 = 0;
        if ( expr.left != null ) d1 = depth(expr.left);
        if ( expr.right != null ) d1 = depth(expr.right);
       // System.out.println( "SUN : " + (1 + Math.max(d1,d2)) );
        return (1 + Math.max(d1,d2) );
    }

    public void isAxiom(Expressions expr){
        String str = expToString();
        isAxiom(str);
    }

    public boolean isAxiom(String expr){

        return true;
    }

    public boolean canBeProved(Expressions expr){

        return true;
    }

}

package logic;

public class UnaryOperator extends Expressions {


}

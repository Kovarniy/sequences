package logic;

    public class Variable extends Expressions {
        public static boolean isVariable(char c) {
            if ( (c >= 97 && c < 118) || (c > 118 && c <= 122) )
                return true;
            else if ( (c >= 65 && c < 86) || (c > 86 && c <= 90) )
                return true;

            return false;
        }

}

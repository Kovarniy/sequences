package logic;

public class BinaryOperator extends Expressions {
}
